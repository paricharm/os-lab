echo -n "Enter first number: "
read a
echo -n "Enter second number: "
read b
sum=$(( $a + $b))
echo "$a + $b = $sum"